// app/limit-increase-requests/new/page.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';

export default function NewLimitIncreaseRequestPage() {
  const router = useRouter();
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const [formData, setFormData] = useState({
    requestedAmount: '',
    reason: '',
    startDate: '',
    endDate: '',
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch('/api/limit-increase-requests', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          requestedAmount: parseFloat(formData.requestedAmount),
          reason: formData.reason,
          startDate: formData.startDate,
          endDate: formData.endDate,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || '申請の作成に失敗しました');
      }

      alert('上限解放申請を送信しました');
      router.push('/limit-increase-requests');
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  // 本日の日付（YYYY-MM-DD形式）
  const today = new Date().toISOString().split('T')[0];

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold text-gray-900">上限解放申請</h1>
        <p className="text-gray-600 mt-2">
          限度額を一時的に引き上げる申請を行います
        </p>
      </div>

      {error && (
        <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg">
          <p className="text-red-800">{error}</p>
        </div>
      )}

      <form onSubmit={handleSubmit} className="bg-white shadow-md rounded-lg p-6">
        {/* 追加金額 */}
        <div className="mb-6">
          <label
            htmlFor="requestedAmount"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            追加で必要な金額 <span className="text-red-500">*</span>
          </label>
          <div className="relative">
            <input
              type="number"
              id="requestedAmount"
              name="requestedAmount"
              value={formData.requestedAmount}
              onChange={handleChange}
              required
              min="1"
              step="1"
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              placeholder="10000"
            />
            <span className="absolute right-4 top-2 text-gray-500">円</span>
          </div>
          <p className="text-sm text-gray-500 mt-1">
            現在の限度額に追加する金額を入力してください
          </p>
        </div>

        {/* 適用期間 */}
        <div className="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label
              htmlFor="startDate"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              適用開始日 <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              id="startDate"
              name="startDate"
              value={formData.startDate}
              onChange={handleChange}
              required
              min={today}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>

          <div>
            <label
              htmlFor="endDate"
              className="block text-sm font-medium text-gray-700 mb-2"
            >
              適用終了日 <span className="text-red-500">*</span>
            </label>
            <input
              type="date"
              id="endDate"
              name="endDate"
              value={formData.endDate}
              onChange={handleChange}
              required
              min={formData.startDate || today}
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
          </div>
        </div>

        {/* 申請理由 */}
        <div className="mb-6">
          <label
            htmlFor="reason"
            className="block text-sm font-medium text-gray-700 mb-2"
          >
            申請理由 <span className="text-red-500">*</span>
          </label>
          <textarea
            id="reason"
            name="reason"
            value={formData.reason}
            onChange={handleChange}
            required
            rows={5}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            placeholder="例: 大型イベント参加のため、通常より多くの交通費・宿泊費が必要です。"
          />
          <p className="text-sm text-gray-500 mt-1">
            できるだけ具体的に記入してください
          </p>
        </div>

        {/* ボタン */}
        <div className="flex gap-4">
          <button
            type="button"
            onClick={() => router.back()}
            className="flex-1 px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
          >
            キャンセル
          </button>
          <button
            type="submit"
            disabled={loading}
            className="flex-1 px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed transition-colors"
          >
            {loading ? '送信中...' : '申請する'}
          </button>
        </div>
      </form>

      {/* 注意事項 */}
      <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
        <h3 className="font-semibold text-yellow-900 mb-2">📌 注意事項</h3>
        <ul className="text-sm text-yellow-800 space-y-1 list-disc list-inside">
          <li>申請は承認されるまで有効になりません</li>
          <li>適用期間は承認後、指定した期間のみ有効です</li>
          <li>期間終了後は自動的に元の限度額に戻ります</li>
        </ul>
      </div>
    </div>
  );
}
