// app/api/limit-increase-requests/[id]/review/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

export async function POST(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: '認証が必要です' }, { status: 401 });
    }

    // MASTER権限チェック
    if (session.user.role !== 'MASTER') {
      return NextResponse.json(
        { error: '承認権限がありません' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { action, comment } = body; // action: 'approve' or 'reject'

    if (!action || !['approve', 'reject'].includes(action)) {
      return NextResponse.json(
        { error: '承認または却下を選択してください' },
        { status: 400 }
      );
    }

    // 申請を取得
    const limitRequest = await prisma.limitIncreaseRequest.findUnique({
      where: { id: params.id },
      include: {
        user: true,
      },
    });

    if (!limitRequest) {
      return NextResponse.json(
        { error: '申請が見つかりません' },
        { status: 404 }
      );
    }

    // すでに承認/却下済みチェック
    if (limitRequest.status !== 'pending') {
      return NextResponse.json(
        { error: 'この申請はすでに処理済みです' },
        { status: 400 }
      );
    }

    const newStatus = action === 'approve' ? 'approved' : 'rejected';

    // 申請を更新
    const updatedRequest = await prisma.limitIncreaseRequest.update({
      where: { id: params.id },
      data: {
        status: newStatus,
        reviewedBy: session.user.id,
        reviewedAt: new Date(),
        reviewComment: comment || null,
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        reviewer: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
    });

    return NextResponse.json({
      message: action === 'approve' ? '申請を承認しました' : '申請を却下しました',
      request: updatedRequest,
    });
  } catch (error) {
    console.error('申請レビューエラー:', error);
    return NextResponse.json(
      { error: '申請の処理に失敗しました' },
      { status: 500 }
    );
  }
}
