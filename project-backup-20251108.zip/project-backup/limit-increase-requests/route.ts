// app/api/limit-increase-requests/route.ts
import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from 'next-auth';
import { authOptions } from '@/lib/auth';
import { prisma } from '@/lib/prisma';

// 申請一覧取得（自分の申請 or MASTER用全申請）
export async function GET(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: '認証が必要です' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const status = searchParams.get('status');

    // MASTERの場合は全ての申請を取得
    const isMaster = session.user.role === 'MASTER';
    
    const where: any = isMaster ? {} : { userId: session.user.id };
    
    if (status && status !== 'all') {
      where.status = status;
    }

    const requests = await prisma.limitIncreaseRequest.findMany({
      where,
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
        reviewer: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    return NextResponse.json(requests);
  } catch (error) {
    console.error('申請一覧取得エラー:', error);
    return NextResponse.json(
      { error: '申請一覧の取得に失敗しました' },
      { status: 500 }
    );
  }
}

// 新規申請作成
export async function POST(request: NextRequest) {
  try {
    const session = await getServerSession(authOptions);
    if (!session?.user) {
      return NextResponse.json({ error: '認証が必要です' }, { status: 401 });
    }

    const body = await request.json();
    const { requestedAmount, reason, startDate, endDate } = body;

    // バリデーション
    if (!requestedAmount || requestedAmount <= 0) {
      return NextResponse.json(
        { error: '追加金額を正しく入力してください' },
        { status: 400 }
      );
    }

    if (!reason || reason.trim().length === 0) {
      return NextResponse.json(
        { error: '申請理由は必須です' },
        { status: 400 }
      );
    }

    if (!startDate || !endDate) {
      return NextResponse.json(
        { error: '適用期間を指定してください' },
        { status: 400 }
      );
    }

    const start = new Date(startDate);
    const end = new Date(endDate);

    if (start >= end) {
      return NextResponse.json(
        { error: '終了日は開始日より後の日付を指定してください' },
        { status: 400 }
      );
    }

    if (start < new Date()) {
      return NextResponse.json(
        { error: '開始日は本日以降の日付を指定してください' },
        { status: 400 }
      );
    }

    // 現在の限度額を取得
    const currentLimit = await prisma.expenseLimit.findUnique({
      where: { userId: session.user.id },
    });

    // 申請作成
    const newRequest = await prisma.limitIncreaseRequest.create({
      data: {
        userId: session.user.id,
        requestedAmount,
        currentLimit: currentLimit?.monthlyLimit || 0,
        reason,
        startDate: start,
        endDate: end,
        status: 'pending',
      },
      include: {
        user: {
          select: {
            id: true,
            name: true,
            email: true,
          },
        },
      },
    });

    return NextResponse.json(newRequest, { status: 201 });
  } catch (error) {
    console.error('申請作成エラー:', error);
    return NextResponse.json(
      { error: '申請の作成に失敗しました' },
      { status: 500 }
    );
  }
}
