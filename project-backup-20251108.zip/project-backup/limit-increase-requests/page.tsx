// app/limit-increase-requests/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useSession } from 'next-auth/react';
import Link from 'next/link';

type LimitIncreaseRequest = {
  id: string;
  requestedAmount: number;
  currentLimit: number;
  reason: string;
  startDate: string;
  endDate: string;
  status: 'pending' | 'approved' | 'rejected';
  reviewedAt: string | null;
  reviewComment: string | null;
  createdAt: string;
  user: {
    id: string;
    name: string;
    email: string;
  };
  reviewer: {
    id: string;
    name: string;
    email: string;
  } | null;
};

export default function LimitIncreaseRequestsPage() {
  const router = useRouter();
  const { data: session } = useSession();
  const [requests, setRequests] = useState<LimitIncreaseRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string>('all');

  useEffect(() => {
    fetchRequests();
  }, [filterStatus]);

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const url = `/api/limit-increase-requests?status=${filterStatus}`;
      const response = await fetch(url);
      const data = await response.json();
      setRequests(data);
    } catch (error) {
      console.error('申請一覧取得エラー:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status: string) => {
    const styles = {
      pending: 'bg-yellow-100 text-yellow-800',
      approved: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
    };

    const labels = {
      pending: '承認待ち',
      approved: '承認済み',
      rejected: '却下',
    };

    return (
      <span
        className={`px-3 py-1 rounded-full text-sm font-medium ${
          styles[status as keyof typeof styles]
        }`}
      >
        {labels[status as keyof typeof labels]}
      </span>
    );
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('ja-JP', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit',
    });
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('ja-JP', {
      style: 'currency',
      currency: 'JPY',
    }).format(amount);
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* ヘッダー */}
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            上限解放申請一覧
          </h1>
          <p className="text-gray-600 mt-2">
            限度額の一時的な引き上げ申請を管理します
          </p>
        </div>
        <Link
          href="/limit-increase-requests/new"
          className="px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          + 新規申請
        </Link>
      </div>

      {/* フィルター */}
      <div className="mb-6 flex gap-2">
        <button
          onClick={() => setFilterStatus('all')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filterStatus === 'all'
              ? 'bg-blue-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          すべて
        </button>
        <button
          onClick={() => setFilterStatus('pending')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filterStatus === 'pending'
              ? 'bg-yellow-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          承認待ち
        </button>
        <button
          onClick={() => setFilterStatus('approved')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filterStatus === 'approved'
              ? 'bg-green-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          承認済み
        </button>
        <button
          onClick={() => setFilterStatus('rejected')}
          className={`px-4 py-2 rounded-lg transition-colors ${
            filterStatus === 'rejected'
              ? 'bg-red-600 text-white'
              : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
          }`}
        >
          却下
        </button>
      </div>

      {/* 申請一覧 */}
      {loading ? (
        <div className="text-center py-12">
          <div className="inline-block animate-spin rounded-full h-8 w-8 border-4 border-gray-300 border-t-blue-600"></div>
          <p className="text-gray-600 mt-4">読み込み中...</p>
        </div>
      ) : requests.length === 0 ? (
        <div className="bg-white rounded-lg shadow-md p-12 text-center">
          <p className="text-gray-600 text-lg">申請がありません</p>
          <Link
            href="/limit-increase-requests/new"
            className="inline-block mt-4 text-blue-600 hover:text-blue-700"
          >
            新規申請を作成
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {requests.map((request) => (
            <div
              key={request.id}
              className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow"
            >
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    {getStatusBadge(request.status)}
                    <span className="text-sm text-gray-500">
                      申請日: {formatDate(request.createdAt)}
                    </span>
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    追加金額: {formatCurrency(request.requestedAmount)}
                  </h3>
                  <p className="text-gray-600">
                    現在の限度額: {formatCurrency(request.currentLimit)} →{' '}
                    <span className="font-semibold text-blue-600">
                      {formatCurrency(
                        request.currentLimit + request.requestedAmount
                      )}
                    </span>
                  </p>
                </div>
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-500 mb-1">適用期間</p>
                <p className="text-gray-900">
                  {formatDate(request.startDate)} 〜{' '}
                  {formatDate(request.endDate)}
                </p>
              </div>

              <div className="mb-4">
                <p className="text-sm text-gray-500 mb-1">申請理由</p>
                <p className="text-gray-900 whitespace-pre-wrap">
                  {request.reason}
                </p>
              </div>

              {request.status !== 'pending' && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <p className="text-sm text-gray-500 mb-1">
                    {request.status === 'approved' ? '承認者' : '却下者'}:{' '}
                    {request.reviewer?.name}
                  </p>
                  {request.reviewedAt && (
                    <p className="text-sm text-gray-500 mb-1">
                      処理日: {formatDate(request.reviewedAt)}
                    </p>
                  )}
                  {request.reviewComment && (
                    <div className="mt-2 p-3 bg-gray-50 rounded">
                      <p className="text-sm text-gray-700">
                        {request.reviewComment}
                      </p>
                    </div>
                  )}
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
